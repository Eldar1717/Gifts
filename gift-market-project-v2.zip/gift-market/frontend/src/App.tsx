import { useEffect, useMemo, useState } from 'react'
import { Store, Gem, UserRound, Plus, ArrowLeft, ShoppingBag, Sparkles, Search, X, Tag, ShieldCheck, ExternalLink } from 'lucide-react'

declare global { interface Window { Telegram?: any } }
const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'
const DEMO = import.meta.env.VITE_DEMO_MODE === 'true'
type Product = {id:number,title:string,description:string,image_url:string,collection:string,rarity:string,price_stars:number,edition_limit:number,minted_count:number,remaining:number,is_ton_nft:boolean,ton_url:string}
type Item = {id:number,serial_number:number,product:Product}
type Listing = {id:number,price_stars:number,seller:string,collectible:Item}
const demoProducts:Product[]=[
 {id:1,title:'Golden Cup',description:'Первый предмет коллекции Genesis.',image_url:'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=600',collection:'Genesis',rarity:'rare',price_stars:300,edition_limit:500,minted_count:124,remaining:376,is_ton_nft:false,ton_url:''},
 {id:2,title:'Liberty Spirit',description:'Символ свободы и коллекционного духа.',image_url:'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=600',collection:'Icons',rarity:'epic',price_stars:571,edition_limit:100,minted_count:42,remaining:58,is_ton_nft:true,ton_url:''},
 {id:3,title:'Magic Lantern',description:'Свет редкой серии.',image_url:'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600',collection:'Magic',rarity:'legendary',price_stars:450,edition_limit:50,minted_count:19,remaining:31,is_ton_nft:false,ton_url:''},
 {id:4,title:'Summer Pop',description:'Яркий предмет летней коллекции.',image_url:'https://images.unsplash.com/photo-1531058020387-3be344556be6?w=600',collection:'Summer',rarity:'common',price_stars:449,edition_limit:1000,minted_count:212,remaining:788,is_ton_nft:false,ton_url:''},
]
const demoItems:Item[]= [{id:101,serial_number:17,product:demoProducts[0]},{id:102,serial_number:8,product:demoProducts[2]}]
const demoListings:Listing[]=[{id:1,price_stars:390,seller:'collector_01',collectible:demoItems[0]}]
function tg(){return window.Telegram?.WebApp}
function auth(){return DEMO?'':`tma ${tg()?.initData||''}`}
async function api(path:string,opts:RequestInit={}) {
 const res=await fetch(`${API}${path}`,{...opts,headers:{'Content-Type':'application/json',Authorization:auth(),...(opts.headers||{})}})
 if(!res.ok) throw new Error((await res.json().catch(()=>({detail:'Ошибка сервера'}))).detail||'Ошибка')
 return res.json()
}
const stars=(n:number)=><span className="stars">★ {n.toLocaleString('ru-RU')}</span>
export default function App(){
 const [tab,setTab]=useState<'shop'|'market'|'collection'|'admin'>('shop')
 const [products,setProducts]=useState<Product[]>(DEMO?demoProducts:[])
 const [items,setItems]=useState<Item[]>(DEMO?demoItems:[])
 const [listings,setListings]=useState<Listing[]>(DEMO?demoListings:[])
 const [user,setUser]=useState<any>({first_name:'Коллекционер',stars_pending:0,is_admin:false})
 const [search,setSearch]=useState('')
 const [filter,setFilter]=useState('all')
 const [selected,setSelected]=useState<Product|null>(null)
 const [notice,setNotice]=useState('')
 const [busy,setBusy]=useState(false)
 const [adminForm,setAdminForm]=useState({title:'',description:'',image_url:'',collection:'Genesis',rarity:'rare',price_stars:300,edition_limit:100})
 const [listPrice,setListPrice]=useState('400')
 const [listTarget,setListTarget]=useState<Item|null>(null)
 const [orders,setOrders]=useState<any[]>([])
 const [stats,setStats]=useState<any>(null)
 const [marketConfig,setMarketConfig]=useState({commission_percent:10,seller_share_percent:90})
 useEffect(()=>{tg()?.ready();tg()?.expand();load()},[])
 async function load(){
   if(DEMO)return
   try{const [p,i,l,u,o,cfg]=await Promise.all([api('/api/catalog'),api('/api/collection'),api('/api/market/listings'),api('/api/me'),api('/api/orders'),api('/api/market/config')]);setProducts(p);setItems(i);setListings(l);setUser(u);setOrders(o);setMarketConfig(cfg)}catch(e:any){setNotice(e.message)}
 }
 const filtered=useMemo(()=>products.filter(p=>(filter==='all'||p.rarity===filter)&&`${p.title} ${p.collection}`.toLowerCase().includes(search.toLowerCase())),[products,filter,search])
 async function buy(p:Product,listingId?:number){
   if(DEMO){setNotice('Демо-режим: подключи BOT_TOKEN и DEV_AUTH=false для реальных платежей.');return}
   setBusy(true)
   try{const data=await api('/api/payments/invoice',{method:'POST',body:JSON.stringify({product_id:p.id,listing_id:listingId||null})})
     if(tg()?.openInvoice) tg().openInvoice(data.invoice_url,(status:string)=>{if(status==='paid'){setNotice('Платёж принят Telegram. Подарок появится после подтверждения сервера.');setTimeout(load,1800)}else if(status==='failed')setNotice('Оплата не прошла')})
     else window.open(data.invoice_url,'_blank')
   }catch(e:any){setNotice(e.message)}finally{setBusy(false)}
 }
 async function listItem(item:Item){
   if(DEMO){setNotice('Демо-режим: выставление на продажу доступно после подключения API.');setListTarget(null);return}
   try{await api('/api/market/list',{method:'POST',body:JSON.stringify({collectible_id:item.id,price_stars:Number(listPrice)})});setNotice('Лот выставлен');setListTarget(null);load()}catch(e:any){setNotice(e.message)}
 }
 async function createProduct(){
   try{await api('/api/admin/products',{method:'POST',body:JSON.stringify(adminForm)});setNotice('Подарок создан');setAdminForm({title:'',description:'',image_url:'',collection:'Genesis',rarity:'rare',price_stars:300,edition_limit:100});load()}catch(e:any){setNotice(e.message)}
 }
 async function openAdmin(){setTab('admin');if(!DEMO){try{setStats(await api('/api/admin/overview'))}catch(e:any){setNotice(e.message)}}}
 return <div className="app">
  <header><div className="brandmark"><Gem size={21}/></div><div><div className="brand">GIFT MARKET</div><div className="subbrand">COLLECT • TRADE • OWN</div></div><div className="header-spacer"/><div className="balance" title="Внутренний ожидающий баланс продавца. Это не кошелёк Telegram и не автоматический вывод.">Баланс {stars(user.stars_pending||0)}</div></header>
  <main>
   {tab==='shop'&&<><section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={13}/> DIGITAL COLLECTIBLES</div><h1>Собери свою<br/><em>легенду.</em></h1><p>Редкие цифровые предметы. Лимитированные коллекции. Твоя история.</p><button className="primary" onClick={()=>setTab('collection')}>Моя коллекция <ArrowLeft size={16}/></button></div><div className="hero-orb">✦</div></section>
    <div className="section-head"><div><div className="eyebrow">CURATED DROPS</div><h2>Новые подарки</h2></div><span className="muted">{products.length} предметов</span></div>
    <div className="search"><Search size={17}/><input placeholder="Найти подарок или коллекцию" value={search} onChange={e=>setSearch(e.target.value)}/>{search&&<X size={16} onClick={()=>setSearch('')}/>}</div>
    <div className="filters">{['all','common','rare','epic','legendary'].map(x=><button className={filter===x?'active':''} onClick={()=>setFilter(x)} key={x}>{x==='all'?'Все':x}</button>)}</div>
    <div className="grid">{filtered.map(p=><ProductCard key={p.id} p={p} onClick={()=>setSelected(p)}/>)}</div>
   </>}
   {tab==='market'&&<><div className="page-title"><div className="eyebrow">PEER TO PEER</div><h1>Вторичный рынок</h1><p>Покупай предметы у других коллекционеров.</p><p className="muted small">Комиссия площадки — {marketConfig.commission_percent}%. Продавцу начисляется {marketConfig.seller_share_percent}% от цены сделки.</p></div>{listings.length?<div className="grid">{listings.map(l=><div className="product-card" key={l.id}><div className="art"><img src={l.collectible.product.image_url}/><span className="edition">#{l.collectible.serial_number}</span></div><div className="product-info"><div className="muted small">{l.collectible.product.collection} · {l.seller}</div><h3>{l.collectible.product.title}</h3><div className="card-bottom">{stars(l.price_stars)}<button className="buy" disabled={busy} onClick={()=>buy(l.collectible.product,l.id)}>Купить</button></div></div></div>)}</div>:<Empty text="Пока нет активных предложений. Загляни позже!"/>}</>}
   {tab==='collection'&&<><div className="page-title"><div className="eyebrow">YOUR INVENTORY</div><h1>Моя коллекция</h1><p>Твои цифровые экземпляры и их номера.</p></div>{items.length?<div className="grid">{items.map(i=><div className="product-card" key={i.id}><div className="art"><img src={i.product.image_url}/><span className="edition">#{i.serial_number}</span></div><div className="product-info"><div className="muted small">{i.product.collection}</div><h3>{i.product.title}</h3><div className="card-bottom"><span className="rarity">{i.product.rarity}</span><button className="outline" onClick={()=>{setListTarget(i);setListPrice('400')}}>Продать</button></div></div></div>)}</div>:<Empty text="Здесь появятся подарки после покупки."/>}
    {orders.length>0&&<div className="orders"><h3>Последние заказы</h3>{orders.map(o=><div className="order" key={o.id}><span>Заказ #{o.id}</span><b>{stars(o.amount)}</b><span className="muted">{o.status}</span></div>)}</div>}</>}
   {tab==='admin'&&<><div className="page-title"><div className="eyebrow">CONTROL ROOM</div><h1>Админ-панель</h1><p>Выпуск коллекций и управление магазином.</p></div>{DEMO?<div className="notice">Демо-режим. Админ-функции заработают после настройки Telegram ID администратора.</div>:<>{stats&&<div className="stats">{Object.entries(stats).map(([k,v])=><div><b>{String(v)}</b><span>{k}</span></div>)}</div>}<div className="admin-form"><h3><Plus size={17}/> Новый подарок</h3>{(['title','description','image_url','collection'] as const).map(k=><label>{k}<input value={adminForm[k]} onChange={e=>setAdminForm({...adminForm,[k]:e.target.value})} placeholder={k}/></label>)}<label>Редкость<select value={adminForm.rarity} onChange={e=>setAdminForm({...adminForm,rarity:e.target.value})}>{['common','rare','epic','legendary'].map(x=><option>{x}</option>)}</select></label><div className="form-row"><label>Цена ⭐<input type="number" value={adminForm.price_stars} onChange={e=>setAdminForm({...adminForm,price_stars:Number(e.target.value)})}/></label><label>Тираж<input type="number" value={adminForm.edition_limit} onChange={e=>setAdminForm({...adminForm,edition_limit:Number(e.target.value)})}/></label></div><button className="primary full" onClick={createProduct}>Создать подарок</button></div></>}</>}
  </main>
  <nav><Nav icon={<Store/>} label="Магазин" active={tab==='shop'} onClick={()=>setTab('shop')}/><Nav icon={<Tag/>} label="Маркет" active={tab==='market'} onClick={()=>setTab('market')}/><Nav icon={<ShoppingBag/>} label="Коллекция" active={tab==='collection'} onClick={()=>setTab('collection')}/>{user.is_admin||DEMO?<Nav icon={<ShieldCheck/>} label="Админ" active={tab==='admin'} onClick={openAdmin}/>:<Nav icon={<UserRound/>} label="Профиль" active={false} onClick={()=>setNotice(`Telegram ID: ${user.telegram_id||'demo'}`)}/>}</nav>
  {selected&&<div className="overlay" onClick={()=>setSelected(null)}><div className="sheet" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setSelected(null)}><X/></button><img className="sheet-art" src={selected.image_url}/><div className="eyebrow">{selected.collection} · {selected.rarity}</div><h2>{selected.title}</h2><p>{selected.description}</p><div className="sheet-meta"><span>Выпущено</span><b>{selected.minted_count} / {selected.edition_limit}</b></div><div className="sheet-meta"><span>Осталось</span><b>{selected.remaining}</b></div>{selected.is_ton_nft&&<div className="ton-note">TON-ready collectible {selected.ton_url&&<a href={selected.ton_url}>Открыть NFT <ExternalLink size={13}/></a>}</div>}<button className="primary full" disabled={busy} onClick={()=>buy(selected)}>Купить за {selected.price_stars} ⭐</button></div></div>}
  {listTarget&&<div className="overlay" onClick={()=>setListTarget(null)}><div className="sheet compact" onClick={e=>e.stopPropagation()}><button className="close" onClick={()=>setListTarget(null)}><X/></button><h2>Выставить на продажу</h2><p>{listTarget.product.title} · #{listTarget.serial_number}</p><label>Цена в Stars<input type="number" min="1" value={listPrice} onChange={e=>setListPrice(e.target.value)}/></label><button className="primary full" onClick={()=>listItem(listTarget)}>Опубликовать лот</button></div></div>}
  {notice&&<div className="toast" onClick={()=>setNotice('')}>{notice}<X size={15}/></div>}
 </div>
}
function ProductCard({p,onClick}:{p:Product,onClick:()=>void}){return <button className="product-card" onClick={onClick}><div className="art"><img src={p.image_url} loading="lazy"/><span className={`rarity-badge ${p.rarity}`}>{p.rarity}</span>{p.remaining<20&&<span className="limited">LIMITED</span>}</div><div className="product-info"><div className="muted small">{p.collection}</div><h3>{p.title}</h3><div className="card-bottom">{stars(p.price_stars)}<span className="remaining">{p.remaining} left</span></div></div></button>}
function Empty({text}:{text:string}){return <div className="empty"><div>✧</div><p>{text}</p></div>}
function Nav({icon,label,active,onClick}:{icon:any,label:string,active:boolean,onClick:()=>void}){return <button className={`nav-item ${active?'selected':''}`} onClick={onClick}>{icon}{label}</button>}
