# Gift Market — Telegram Mini App

A runnable MVP for a Telegram digital-collectibles shop:
- React + Vite mobile-first Mini App
- FastAPI backend + SQLAlchemy
- SQLite locally / PostgreSQL in production
- Telegram Stars (`XTR`) primary purchases and P2P marketplace purchases
- Telegram `initData` HMAC verification
- Telegram webhook for `pre_checkout_query` and `successful_payment`
- Admin API + in-app admin screen
- Internal collectible ownership, rarity, editions, listings and seller ledger
- Fixed 10% marketplace commission (configurable by operator)
- 15-minute listing reservation during checkout to reduce double-sales
- Seller relisting after a previous listing was sold/cancelled
- Seller cancellation of active listings
- Automatic Telegram Stars refund attempt if payment succeeds but delivery cannot be completed

## Important product boundaries

This MVP sells **platform collectibles** represented by database records and artwork. It does not mint official Telegram collectible gifts and does not mint TON NFTs. Those require separate Telegram-native gift flows or a deployed TON NFT collection contract and wallet integration.

Stars paid to the bot are received by the bot owner. This project credits sellers with an **internal pending balance** after a marketplace sale: 90% to the seller and 10% platform commission by default. It does not automatically transfer Stars or fiat to sellers. The balance shown in the UI is not a withdrawable wallet. A lawful payout process, identity checks where required, terms, accounting and dispute/refund rules must be designed before sellers are promised withdrawals.

Telegram requires digital goods/services sold inside bots and Mini Apps to use Telegram Stars (`XTR`). See the official documentation:
- https://core.telegram.org/bots/payments-stars
- https://core.telegram.org/bots/webapps
- https://core.telegram.org/bots/api

## 1. Requirements

- Python 3.11+
- Node.js 20+
- Telegram bot token from `@BotFather`
- Public HTTPS URL for webhook + Mini App in production

## 2. Local setup

### Backend

```bash
cd backend
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env`:
- `BOT_TOKEN` — token from BotFather
- `ADMIN_TELEGRAM_IDS` — comma-separated numeric Telegram IDs
- `DEV_AUTH=true` — only for local browser development
- `PUBLIC_BASE_URL` — backend public URL (for Telegram webhook)

Засейдить демонстрационный каталог (в отдельном терминале из `backend`, с активированным окружением):

```bash
python seed.py
```

Start API:

```bash
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Open http://localhost:5173

For browser-only local preview, set `VITE_DEMO_MODE=true`. In this mode the UI uses demo user ID 10001. Never enable demo auth in production.

## 3. Telegram bot setup

1. Create a bot with `@BotFather`.
2. Set its Mini App URL using `/newapp` or configure the Main Mini App in BotFather.
3. Set `WEBAPP_URL` to the deployed frontend URL.
4. Set `BOT_TOKEN` in backend `.env`.
5. Deploy backend with HTTPS and set `PUBLIC_BASE_URL`.
6. Register webhook:

```bash
curl -X POST "https://api.telegram.org/bot< BOT_TOKEN >/setWebhook" \
  -d "url=https://YOUR_API_HOST/telegram/webhook"
```

Replace the placeholder with the real token (without spaces). For production, set `WEBHOOK_SECRET` and register webhook with `secret_token`:

```bash
curl -X POST "https://api.telegram.org/bot$BOT_TOKEN/setWebhook" \
  -d "url=$PUBLIC_BASE_URL/telegram/webhook" \
  -d "secret_token=$WEBHOOK_SECRET"
```

The backend checks `X-Telegram-Bot-Api-Secret-Token` when `WEBHOOK_SECRET` is configured.

## 4. Production deployment (Docker Compose)

1. Copy `.env.example` to `.env` in `backend` and fill secrets.
2. At repository root:

```bash
docker compose up --build -d
```

The API listens on port 8000. Put it behind a TLS reverse proxy (Caddy, Nginx, Traefik) and serve the frontend from a static host (or add your own frontend container). Set the Mini App URL to the HTTPS frontend URL and API URL to the HTTPS backend URL.

For a quick frontend production build:

```bash
cd frontend
npm ci
npm run build
```

Upload `frontend/dist` to Vercel, Netlify, Cloudflare Pages or your own static server. Set `VITE_API_URL=https://YOUR_API_HOST`.

## 5. Admin

Admin is granted only when the validated Telegram user ID is in `ADMIN_TELEGRAM_IDS`.

Admin endpoints:
- `GET /api/admin/overview`
- `POST /api/admin/products`
- `PATCH /api/admin/products/{product_id}`
- `POST /api/admin/products/{product_id}/publish`

The in-app Admin tab lets you create a product. For artwork, enter an absolute HTTPS image URL. For local development, use a public image URL or serve assets from the frontend `public` folder.

## 6. How purchases work

1. Frontend requests `/api/payments/invoice`.
2. Backend creates a pending order and calls Telegram `createInvoiceLink` with `currency=XTR`.
3. Mini App opens the returned invoice URL using `Telegram.WebApp.openInvoice`.
4. Telegram sends `pre_checkout_query`; webhook handler approves only a valid pending order.
5. Telegram sends `successful_payment`; backend verifies payload, amount and currency, then fulfills the order idempotently.
6. For a marketplace purchase, the listing is reserved for up to 15 minutes; after verified payment, ownership transfers, 10% is recorded as platform commission and 90% is credited to the seller internal pending balance. If delivery fails after capture, the webhook attempts a Telegram Stars refund and marks the order `refund_pending` if the refund call fails.

Do not fulfill orders from the frontend invoice-closed callback. Only the verified `successful_payment` update fulfills an order.

## 7. Marketplace rules

- Default `STARS_FEE_PERCENT=10`; seller share is 90%.
- Commission is rounded down to a whole Star (`fee = amount * percent // 100`); the remainder is credited to the seller.
- Listings are reserved for 15 minutes while a buyer checks out. Expired reservations are released when marketplace endpoints are used.
- A collectible can be listed again after a previous listing is sold or cancelled.
- `GET /api/market/config` returns the public commission settings.
- `POST /api/market/{listing_id}/cancel` lets the owner cancel an active listing.
- Admin overview includes accumulated platform commission and seller pending balances.

## 8. Before going live

- Set `DEV_AUTH=false`.
- Use HTTPS.
- Use PostgreSQL and automated backups.
- Set a strong `WEBHOOK_SECRET`.
- Configure BotFather Mini App domain and URL.
- Add your terms, privacy policy, support contact, refund policy and age/region restrictions as appropriate.
- Test payments with a dedicated test bot before production.
- Add rate limiting, monitoring, structured logs and fraud review.
- Review Telegram's current Stars terms and applicable laws.
- Implement a real seller payout process before promising cash-outs.
- For TON NFT minting, deploy/audit a collection contract and implement wallet signing; do not store seed phrases.

## 9. API overview

- `GET /api/health`
- `GET /api/catalog`
- `GET /api/me`
- `GET /api/collection`
- `GET /api/market/config`
- `GET /api/market/listings`
- `POST /api/market/{listing_id}/cancel`
- `POST /api/market/list`
- `POST /api/payments/invoice`
- `GET /api/orders`
- `POST /api/telegram/webhook`

All app endpoints except health/catalog require Telegram initData in `Authorization: tma <initData>` header, unless local `DEV_AUTH=true`.


### Database note

This MVP uses `Base.metadata.create_all()` and does not yet include Alembic migrations. If upgrading an existing database created by an earlier ZIP, back it up and use a fresh database for this iteration, or create/apply a proper migration for the new order and listing reservation columns before deployment. Do not delete a live database containing real customer transactions.
