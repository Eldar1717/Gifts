from app.db import Base, engine, SessionLocal
from app.models import Product
Base.metadata.create_all(bind=engine)
db=SessionLocal()
samples=[
 ("Golden Cup","Золотой артефакт первой коллекции.","https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?w=600","Genesis","rare",300,500),
 ("Liberty Spirit","Символ свободы и независимости.","https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=600","Icons","epic",571,100),
 ("Magic Lantern","Свет редкой серии.","https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600","Magic","legendary",450,50),
 ("Summer Pop","Яркий предмет летней коллекции.","https://images.unsplash.com/photo-1531058020387-3be344556be6?w=600","Summer","common",449,1000),
]
for title,desc,img,col,rarity,price,limit in samples:
 if not db.query(Product).filter_by(title=title).first():
  db.add(Product(title=title,description=desc,image_url=img,collection=col,rarity=rarity,price_stars=price,edition_limit=limit,is_published=True))
db.commit()
print("Seed complete")
