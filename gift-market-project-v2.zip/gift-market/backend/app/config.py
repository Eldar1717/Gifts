from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "Gift Market API"
    database_url: str = "sqlite:///./gift_market.db"
    bot_token: str = ""
    bot_username: str = ""
    webapp_url: str = ""
    public_base_url: str = ""
    webhook_secret: str = ""
    admin_telegram_ids: str = ""
    dev_auth: bool = False
    dev_telegram_id: int = 10001
    stars_fee_percent: int = Field(default=10, ge=0, le=100)
    init_data_max_age_seconds: int = 86400
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def admins(self) -> set[int]:
        return {int(x.strip()) for x in self.admin_telegram_ids.split(",") if x.strip().isdigit()}

settings = Settings()
