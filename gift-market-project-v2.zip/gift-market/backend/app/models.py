from datetime import datetime, timezone
from sqlalchemy import String, Integer, Boolean, DateTime, ForeignKey, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .db import Base

def now():
    return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    telegram_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    username: Mapped[str] = mapped_column(String(64), default="")
    first_name: Mapped[str] = mapped_column(String(128), default="")
    stars_pending: Mapped[int] = mapped_column(Integer, default=0)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    title: Mapped[str] = mapped_column(String(80))
    description: Mapped[str] = mapped_column(Text, default="")
    image_url: Mapped[str] = mapped_column(Text, default="")
    collection: Mapped[str] = mapped_column(String(80), default="Genesis")
    rarity: Mapped[str] = mapped_column(String(24), default="common")
    price_stars: Mapped[int] = mapped_column(Integer)
    edition_limit: Mapped[int] = mapped_column(Integer, default=100)
    minted_count: Mapped[int] = mapped_column(Integer, default=0)
    is_published: Mapped[bool] = mapped_column(Boolean, default=True)
    is_ton_nft: Mapped[bool] = mapped_column(Boolean, default=False)
    ton_url: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

class Collectible(Base):
    __tablename__ = "collectibles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    serial_number: Mapped[int] = mapped_column(Integer)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    acquired_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    product = relationship("Product")
    __table_args__ = (UniqueConstraint("product_id", "serial_number"),)

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    payload: Mapped[str] = mapped_column(String(128), unique=True, index=True)
    buyer_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"))
    collectible_id: Mapped[int | None] = mapped_column(ForeignKey("collectibles.id"), nullable=True)
    listing_id: Mapped[int | None] = mapped_column(ForeignKey("listings.id"), nullable=True)
    amount: Mapped[int] = mapped_column(Integer)
    currency: Mapped[str] = mapped_column(String(8), default="XTR")
    status: Mapped[str] = mapped_column(String(20), default="pending")
    telegram_charge_id: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    paid_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    platform_fee_stars: Mapped[int] = mapped_column(Integer, default=0)
    seller_net_stars: Mapped[int] = mapped_column(Integer, default=0)

class Listing(Base):
    __tablename__ = "listings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    collectible_id: Mapped[int] = mapped_column(ForeignKey("collectibles.id"), unique=True)
    seller_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    price_stars: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(20), default="active")
    reserved_payload: Mapped[str] = mapped_column(String(128), default="")
    reserved_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    collectible = relationship("Collectible")
    seller = relationship("User")

class LedgerEntry(Base):
    __tablename__ = "ledger_entries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"))
    amount_stars: Mapped[int] = mapped_column(Integer)
    entry_type: Mapped[str] = mapped_column(String(24), default="market_sale")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
