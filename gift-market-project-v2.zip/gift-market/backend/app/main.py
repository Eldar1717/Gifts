from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
from .config import settings
from .db import Base, engine, get_db
from .models import User, Product, Collectible, Order, Listing, LedgerEntry
from .schemas import InvoiceRequest, ListingRequest, ProductCreate
from .auth import get_current_user
from .telegram import create_stars_invoice, tg_call

Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

def current(authorization: str | None, db: Session):
    return get_current_user(authorization=authorization, db=db)

def product_dict(p):
    return {"id":p.id,"title":p.title,"description":p.description,"image_url":p.image_url,
            "collection":p.collection,"rarity":p.rarity,"price_stars":p.price_stars,
            "edition_limit":p.edition_limit,"minted_count":p.minted_count,
            "remaining":max(0,p.edition_limit-p.minted_count),"is_ton_nft":p.is_ton_nft,"ton_url":p.ton_url}

def release_expired_reservations(db: Session):
    now = datetime.now(timezone.utc)
    expired = db.query(Listing).filter(Listing.status == "reserved", Listing.reserved_until < now).all()
    for listing in expired:
        order = db.query(Order).filter_by(payload=listing.reserved_payload, status="pending").first()
        if order:
            order.status = "expired"
        listing.status = "active"
        listing.reserved_payload = ""
        listing.reserved_until = None
    if expired:
        db.commit()

def collectible_dict(c):
    return {"id":c.id,"serial_number":c.serial_number,"acquired_at":c.acquired_at.isoformat(),
            "product":product_dict(c.product)}

@app.get("/api/market/config")
def market_config():
    return {"commission_percent": settings.stars_fee_percent, "seller_share_percent": 100-settings.stars_fee_percent,
            "currency": "XTR", "seller_balance_type": "internal_pending"}

@app.get("/api/health")
def health():
    return {"ok":True,"service":"gift-market"}

@app.get("/api/catalog")
def catalog(db: Session=Depends(get_db)):
    products=db.query(Product).filter_by(is_published=True).order_by(desc(Product.created_at)).all()
    return [product_dict(p) for p in products if p.minted_count < p.edition_limit]

@app.get("/api/me")
def me(authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    return {"telegram_id":u.telegram_id,"username":u.username,"first_name":u.first_name,
            "stars_pending":u.stars_pending,"is_admin":u.is_admin}

@app.get("/api/collection")
def collection(authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    rows=db.query(Collectible).filter_by(owner_id=u.id).order_by(desc(Collectible.acquired_at)).all()
    return [collectible_dict(c) for c in rows]

@app.get("/api/orders")
def orders(authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    rows=db.query(Order).filter_by(buyer_id=u.id).order_by(desc(Order.created_at)).limit(50).all()
    return [{"id":o.id,"amount":o.amount,"status":o.status,"created_at":o.created_at.isoformat()} for o in rows]

@app.get("/api/market/listings")
def listings(db: Session=Depends(get_db)):
    release_expired_reservations(db)
    rows=db.query(Listing).filter_by(status="active").order_by(desc(Listing.created_at)).all()
    out=[]
    for l in rows:
        c=l.collectible
        out.append({"id":l.id,"price_stars":l.price_stars,"seller":l.seller.username or "Collector",
                    "collectible":collectible_dict(c)})
    return out

@app.post("/api/market/list")
def create_listing(body: ListingRequest, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    release_expired_reservations(db)
    c=db.query(Collectible).filter_by(id=body.collectible_id,owner_id=u.id).with_for_update().first()
    if not c: raise HTTPException(404,"Collectible not found or not yours")
    existing=db.query(Listing).filter_by(collectible_id=c.id).order_by(desc(Listing.id)).first()
    if existing and existing.status in {"active", "reserved"}:
        raise HTTPException(409,"Already listed or reserved for purchase")
    if existing:
        existing.seller_id=u.id; existing.price_stars=body.price_stars; existing.status="active"
        existing.reserved_payload=""; existing.reserved_until=None
        listing=existing
    else:
        listing=Listing(collectible_id=c.id,seller_id=u.id,price_stars=body.price_stars)
        db.add(listing)
    db.commit(); db.refresh(listing)
    return {"ok":True,"listing_id":listing.id,"commission_percent":settings.stars_fee_percent}

@app.post("/api/market/{listing_id}/cancel")
def cancel_listing(listing_id:int, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    listing=db.query(Listing).filter_by(id=listing_id, seller_id=u.id, status="active").first()
    if not listing: raise HTTPException(404,"Active listing not found")
    listing.status="cancelled"; db.commit()
    return {"ok":True}

@app.post("/api/payments/invoice")
async def invoice(body: InvoiceRequest, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    u=current(authorization,db)
    release_expired_reservations(db)
    if body.listing_id:
        listing=db.query(Listing).filter_by(id=body.listing_id,status="active").with_for_update().first()
        if not listing: raise HTTPException(404,"Listing unavailable")
        if listing.seller_id==u.id: raise HTTPException(400,"You cannot buy your own item")
        c=listing.collectible
        p=c.product
        amount=listing.price_stars
    else:
        p=db.query(Product).filter_by(id=body.product_id,is_published=True).first()
        if not p or p.minted_count>=p.edition_limit: raise HTTPException(404,"Product unavailable")
        amount=p.price_stars
        c=None
    payload=f"gm_{u.id}_{int(datetime.now(timezone.utc).timestamp())}_{__import__('secrets').token_hex(5)}"
    order=Order(payload=payload,buyer_id=u.id,product_id=p.id,collectible_id=c.id if c else None,
                listing_id=body.listing_id,amount=amount)
    db.add(order); db.flush()
    if body.listing_id:
        listing.status="reserved"; listing.reserved_payload=payload
        listing.reserved_until=datetime.now(timezone.utc)+__import__('datetime').timedelta(minutes=15)
    db.commit(); db.refresh(order)
    try:
        link=await create_stars_invoice(p.title, f"Gift Market: {p.title}", payload, amount)
    except Exception as e:
        order.status="failed"
        if body.listing_id:
            listing=db.query(Listing).filter_by(id=body.listing_id, reserved_payload=payload).first()
            if listing: listing.status="active"; listing.reserved_payload=""; listing.reserved_until=None
        db.commit()
        raise HTTPException(502,"Telegram invoice creation failed")
    return {"invoice_url":link,"order_id":order.id}

@app.post("/telegram/webhook")
async def webhook(request: Request, db: Session=Depends(get_db), x_telegram_bot_api_secret_token: str | None=Header(default=None)):
    if settings.webhook_secret and x_telegram_bot_api_secret_token != settings.webhook_secret:
        raise HTTPException(403,"Invalid webhook secret")
    update=await request.json()
    if "pre_checkout_query" in update:
        q=update["pre_checkout_query"]
        order=db.query(Order).filter_by(payload=q.get("invoice_payload"),status="pending").first()
        ok=bool(order and order.amount==q.get("total_amount") and q.get("currency")=="XTR")
        if ok and order.listing_id:
            listing=db.query(Listing).filter_by(id=order.listing_id,status="reserved",reserved_payload=order.payload).first()
            ok=bool(listing and listing.reserved_until and listing.reserved_until.replace(tzinfo=timezone.utc)>datetime.now(timezone.utc))
        await tg_call("answerPreCheckoutQuery",{"pre_checkout_query_id":q["id"],"ok":ok,
            "error_message":None if ok else "Лот уже недоступен. Попробуйте обновить маркет."})
        return {"ok":True}
    message=update.get("message") or update.get("edited_message") or {}
    payment=message.get("successful_payment")
    if payment:
        payload=payment.get("invoice_payload")
        order=db.query(Order).filter_by(payload=payload).with_for_update().first()
        if order and order.status=="pending" and payment.get("currency")=="XTR" and payment.get("total_amount")==order.amount:
            buyer=db.query(User).filter_by(id=order.buyer_id).first()
            fulfilled=False
            if order.listing_id:
                listing=db.query(Listing).filter_by(id=order.listing_id,status="reserved",reserved_payload=order.payload).with_for_update().first()
                if listing and listing.reserved_until and listing.reserved_until.replace(tzinfo=timezone.utc)>datetime.now(timezone.utc):
                    c=db.query(Collectible).filter_by(id=listing.collectible_id,owner_id=listing.seller_id).with_for_update().first()
                    seller=db.query(User).filter_by(id=listing.seller_id).first()
                    if c and seller and buyer:
                        fee=order.amount*settings.stars_fee_percent//100
                        net=order.amount-fee
                        c.owner_id=buyer.id; c.acquired_at=datetime.now(timezone.utc)
                        listing.status="sold"; listing.reserved_payload=""; listing.reserved_until=None
                        seller.stars_pending+=net
                        order.platform_fee_stars=fee; order.seller_net_stars=net; order.status="paid"
                        db.add(LedgerEntry(user_id=seller.id,order_id=order.id,amount_stars=net,entry_type="market_sale"))
                        fulfilled=True
            else:
                p=db.query(Product).filter_by(id=order.product_id).with_for_update().first()
                if p and p.minted_count<p.edition_limit and buyer:
                    p.minted_count+=1
                    c=Collectible(product_id=p.id,owner_id=buyer.id,serial_number=p.minted_count)
                    db.add(c); db.flush()
                    order.collectible_id=c.id; order.status="paid"; fulfilled=True
            order.telegram_charge_id=payment.get("telegram_payment_charge_id","")
            order.paid_at=datetime.now(timezone.utc)
            if not fulfilled:
                # Payment was captured but the item could not be delivered: refund via Telegram.
                try:
                    await tg_call("refundStarPayment", {"user_id":message.get("from",{}).get("id"),
                        "telegram_payment_charge_id":order.telegram_charge_id})
                    order.status="refunded"
                except Exception:
                    order.status="refund_pending"
            db.commit()
    return {"ok":True}

def require_admin(authorization, db):
    u=current(authorization,db)
    if not u.is_admin: raise HTTPException(403,"Admin only")
    return u

@app.get("/api/admin/overview")
def admin_overview(authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    require_admin(authorization,db)
    return {"users":db.query(User).count(),"products":db.query(Product).count(),
            "collectibles":db.query(Collectible).count(),"active_listings":db.query(Listing).filter_by(status="active").count(),
            "paid_orders":db.query(Order).filter_by(status="paid").count(),
            "platform_fee_stars":db.query(func.coalesce(func.sum(Order.platform_fee_stars),0)).filter_by(status="paid").scalar(),
            "seller_pending_stars":db.query(func.coalesce(func.sum(User.stars_pending),0)).scalar()}

@app.post("/api/admin/products")
def admin_create_product(body: ProductCreate, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    require_admin(authorization,db)
    if body.rarity not in {"common","rare","epic","legendary"}: raise HTTPException(400,"Invalid rarity")
    p=Product(**body.model_dump(),is_published=True)
    db.add(p); db.commit(); db.refresh(p)
    return product_dict(p)

@app.patch("/api/admin/products/{product_id}")
def admin_update_product(product_id:int, body:dict, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    require_admin(authorization,db)
    p=db.query(Product).filter_by(id=product_id).first()
    if not p: raise HTTPException(404,"Product not found")
    allowed={"title","description","image_url","collection","rarity","price_stars","edition_limit","is_published","ton_url"}
    for k,v in body.items():
        if k in allowed: setattr(p,k,v)
    db.commit()
    return product_dict(p)

@app.post("/api/admin/products/{product_id}/publish")
def admin_publish(product_id:int, authorization: str | None=Header(default=None), db: Session=Depends(get_db)):
    require_admin(authorization,db)
    p=db.query(Product).filter_by(id=product_id).first()
    if not p: raise HTTPException(404,"Product not found")
    p.is_published=True; db.commit()
    return {"ok":True}
