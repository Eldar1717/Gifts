import hashlib, hmac, json, time
from urllib.parse import parse_qsl
from fastapi import Header, HTTPException
from .config import settings

def validate_init_data(init_data: str) -> dict:
    if not settings.bot_token:
        raise HTTPException(503, "BOT_TOKEN is not configured")
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash")
        auth_date = int(pairs.get("auth_date", "0"))
    except Exception:
        raise HTTPException(401, "Invalid Telegram initData")
    if time.time() - auth_date > settings.init_data_max_age_seconds or auth_date > time.time() + 60:
        raise HTTPException(401, "Telegram session expired")
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", settings.bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Telegram signature verification failed")
    try:
        user = json.loads(pairs["user"])
    except Exception:
        raise HTTPException(401, "Telegram user missing")
    return user

def get_current_user(authorization: str | None = Header(default=None), db=None):
    from .models import User
    if settings.dev_auth:
        tg_user = {"id": settings.dev_telegram_id, "username": "demo_user", "first_name": "Demo"}
    else:
        if not authorization or not authorization.startswith("tma "):
            raise HTTPException(401, "Telegram authorization required")
        tg_user = validate_init_data(authorization[4:])
    user = db.query(User).filter_by(telegram_id=int(tg_user["id"])).first()
    if not user:
        user = User(telegram_id=int(tg_user["id"]), username=tg_user.get("username", ""),
                    first_name=tg_user.get("first_name", ""), is_admin=int(tg_user["id"]) in settings.admins)
        db.add(user); db.commit(); db.refresh(user)
    else:
        user.username = tg_user.get("username", user.username or "")
        user.first_name = tg_user.get("first_name", user.first_name or "")
        user.is_admin = user.telegram_id in settings.admins
        db.commit()
    return user
