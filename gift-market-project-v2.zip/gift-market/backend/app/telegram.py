import httpx
from .config import settings

async def tg_call(method: str, payload: dict):
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN is not configured")
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.post(f"https://api.telegram.org/bot{settings.bot_token}/{method}", json=payload)
        response.raise_for_status()
        data = response.json()
        if not data.get("ok"):
            raise RuntimeError(data.get("description", "Telegram API error"))
        return data["result"]

async def create_stars_invoice(title: str, description: str, payload: str, amount: int):
    return await tg_call("createInvoiceLink", {
        "title": title[:32],
        "description": description[:255] or title,
        "payload": payload,
        "currency": "XTR",
        "prices": [{"label": title[:32], "amount": amount}]
    })
