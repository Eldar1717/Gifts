from pydantic import BaseModel, Field, HttpUrl

class InvoiceRequest(BaseModel):
    product_id: int
    listing_id: int | None = None

class ListingRequest(BaseModel):
    collectible_id: int
    price_stars: int = Field(ge=1, le=100000)

class ProductCreate(BaseModel):
    title: str = Field(min_length=2, max_length=80)
    description: str = Field(default="", max_length=2000)
    image_url: str
    collection: str = Field(default="Genesis", max_length=80)
    rarity: str = "common"
    price_stars: int = Field(ge=1, le=100000)
    edition_limit: int = Field(ge=1, le=1000000)
    is_ton_nft: bool = False
    ton_url: str = ""
